<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>City Listing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <h2><strong>City Listing</strong></h2>
    <p><a href="details.php?id=P">Paris</a></p>    
    <p><a href="details.php?id=L">London</a></p>    
    <p><a href="details.php?id=SF">San Francisco</a></p>    
    <p><a href="details.php?id=NY">New York</a></p>    
</body>
</html>