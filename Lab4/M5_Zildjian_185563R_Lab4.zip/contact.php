<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>World Tours: About</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

<body>
<table width="750" border="0" cellpadding="3" cellspacing="0">
 <tr>
      
   <td><img src="images/banner_left.jpg" width="451" height="68"  alt="World Tours Banner, Left" /></td>
 <td width="135"><img src="images/stonehenge.jpg" width="135" height="68" alt="World Tours Banner,Right"/></td>
  <td width="135"><img src="images/dc.jpg" width="135" height="68" alt="World Tours Banner,Right"/></td>
 </tr>
 <tr>
  <td><img src="images/navbar.gif" name="navbar" width="450" height="20" border="0" usemap="#navbarMap" alt="Navigation Bar" /></td>
  <td>&nbsp;</td>
 </tr>
 <tr>
  <td colspan="2">	
	<h1><br />
	  Contact a World Tours Agent</h1>
	<p><img src="images/fountain_versailles.jpg" width="300" height="201" align="left" />If you are interested in learning more about a tour, contact one of our agents:</p>
	<table width="400" border="1" cellspacing="0" cellpadding="3" summary="World Tours contact information">
      <tr>
        <td>By Mail</td>
        <td>By Email or Phone</td>
      </tr>
      <tr>
        <td><p>World Tours<br />
          123 Wharton Street #45<br />
          New York, NY 10010</p>          </td>
        <td><p>info@Worldtours.com<br />
          (555) 555-3865</p>          </td>
      </tr>
    </table>	<p>&nbsp;</p>
    <p><em>Image: This photo of a fountain in Versailles was taken by a World Tours customer on the &quot;Highlights of France&quot; tour. </em></p></td>
 </tr>
</table>

<br />
<br />


<map name="navbarMap" id="navbarMap">
 <area shape="rect" coords="1,0,62,20" href="index.html" alt="Home" />
 <area shape="rect" coords="71,0,117,20" href="about.html" alt="About" />
 <area shape="rect" coords="129,0,196,20" href="tours.html" alt="Find Tours" />
 <area shape="rect" coords="209,0,311,20" href="profiles.html" alt="Country Profiles" />
 <area shape="rect" coords="327,0,434,20" href="contact.php" alt="Contact An Agent" />
</map>
</body>
</html>