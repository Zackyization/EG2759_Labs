<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>test_form_processor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    "Thank you, <b><?php echo $_POST['firstname'];?></b>, for filling out my form."
</body>
</html>